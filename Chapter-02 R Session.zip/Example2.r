

p = 5600
r = 8
t = 3

pery = p*r/100
total = pery*t 

t = p+ total 
p*(1+r*t)


##
days = 34433
weeks = days /7



##WAP to check given no is odd of even 
#IF ELSE 
n = 11
if( n%%2==0 ){
  
    print("even no")
  
}else{
  
  print("odd no ")
}

##wAP to calculate the GST
#IF ELSE IF ELSE IF... ELSE 
amt = 500
tax = 0

if(amt >10000){
  
  tax = (amt * 28)/100
  
}else if(amt>1000){
  
  tax = (amt * 12)/100
  
}else if(amt>500){
  
  tax = (amt * 5)/100
  
}else{
  tax = (amt * 1)/100
}


total = amt+tax
print(total)



##WAP to compare / show greater number fro three inputs
#MULTIPLE CONDITION 
a =111
b =44
c =66

if(a>b  && a>c){
  
    print("a is greater ")
  
}else if(b>a && b>c){
  
  print("b is greater ")
}else{
  
  print("c is greater")
}



###########NESTED IF ELSE 
if(a>b){
  
  
  if(a>c){
      print("a is greater")
  }else{
    print("c is greater ")
  }
}else{
  
    if(b>c){
      print("b is greater")
    }else{
      print("c is greater")
    }
  
}


a = 40
b = 55
c = 70 
d = 58
e = 90
f=mean(a,b,c,d,e)

if(f>=60){
  
  print("first division")
  
}else if(f>50 && f<=59)
  {
    print("second divison")
  
}else if(f>40 && f<=49){
  
    print("third divison")
  
}else {
    print("fail")
  }


#####Q. B10
s= 14000
hra = 0
da = 0

if(s>5000 && s<=10000){
  
  hra= (s*10)/100
  da = (s*5)/100
  
}else if(s>10000 && s<15000){
  
  
  hra= (s*15)/100
  da = (s*8)/100
  
}

print(hra)
print(da)


print(hra)

if(s>5000 && s<=10000){
  da = (s*5)/100
  
}else if(s>10000 && s<15000){
  da = (s*8)/100
}
print(da)


### Q. B10

u = 150
x = 0
if(u<=100){
  x= (u*40)/100 + 50
} else if (u>100 && u<=200){
  x = (u*50)/100 + 50
  
} else {
  x = (u*60)/100 + 50
}
print(x)


##



##while loop
i =1  #start from 
while (i<=100){  #condition 
  
  print(i)
  
  i =i+1 #increment 
}

#print in reverse 
i =100  #start from 
while (i>=1){  #condition 
  
  print(i)
  
  i =i-1 #decrement 
}


#table of 4 
i =1
while(i<=10){
  
  print(i*4)
  i =i+1
}

#wap to get sum of all even and odd numebers
se =0
so =0
i =1
while (i<=100){
  
  if(i%%2==0){
    
    se =se+i
  }else{
    so=so+i
  }
  i =i+1
}
print(se)
print(so)

