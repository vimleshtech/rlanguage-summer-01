
a =10000
b =5555


#declare the variables and assign the data 
n1 = 100
n2 <- 200
300 -> n3

#show data / print data 
n1
n2
n3 

#or 
print(n1)
print(n2)
print(n3)



##check data type
a =111
is.numeric(a)

name ="Jatin"
is.numeric(name)


#convert 
a ="1"
b = "2"

a = as.numeric(a)  #string to numebr 
b = as.numeric(b)

a+b


#keywords
letters
LETTERS
month.name


#Vector and it's operation 
sales = c(1:10) #from 1 to 10

sales = c(10000:1000000) 
sales = c(33333,4444,5555,3333,4555,3222,33,4555,4444) 
#highest number 
max(sales)
min(sales)
mean(sales)

sales*2


#Q. take marks in five subjects (cs,ms,ec,hs,es) and shot total score and average


cs<-56
ms<-35
ec<-47
hs<-98
es<-57 
total  = cs+ms+es+hs+es
total 
#average marks
total/5 




#Factor and it's operation  : is categorial data for example : male /female 

data <- c("india","us","india","uk")  #vector 

data = as.factor(data) #convert vector to factor 
data


##matrix 
d = c(1:12)

matrix(d,nrow = 3) #nrow : no rows 
matrix(d,nrow = 4)


###
data <- c(1111,222,3344,5565,666)

data
data[1]
data[3]
data[5]

data[2:5]


###questions 
a=2
a*a


b=3
#b*b*b
b^3  #b power 3 


r=2
area=(22/7)*r*r
area

circumference= 2*(22/7)*r
circumference


a =3 
b = 4
c = 5
d  = 6

a = a^3
b = b^3
c = c^3
d = d^3


if (a+b+c == d){
  
    print('condition is match')
  
}else{
  
  print('conditin is not match')
}
