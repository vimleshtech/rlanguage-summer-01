
#####
#function example
#no argument no return

test <- function(){
  
  print("hi, this is test function ")
  print("we are learning  r data science ")
  
}

#no argument with return 
getNum <- function(){
  
  n = readline(prompt = "ener data ")
  return( as.numeric( n))
}


#argument with return
addNum <- function(a,b){
  
  c = a+b
  print(c)
}

#argument with return
subNum <- function(a,b){
  
  c = a+b
   return(c)
}


#call to function 
test()

getNum()+getNum()


 x= getNum()
 y = getNum()
 
 x*y 


 #
 addNum(222,333)
 addNum(3222,333)
 

 addNum(getNum(),getNum())
 
 
 o = subNum(11,22)
 
 addNum(o,11)